const express = require("express");
const dotenv = require("dotenv").config();
const passport = require("passport");
const session = require('express-session');

const { errorHandler } = require("./middleware/errorMiddleware");
const PORT = process.env.PORT || 5000;
const cors = require('cors');
const connectDB = require("./config/db");

const app = express();
require("./controllers/auth/passportGoogleSSO");


connectDB();

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use((req, res, next) => {
  if (req.originalUrl === '/api/stripe/webhook') {
    next();
  } else {
    express.json()(req, res, next);
  }
});
app.use(session({
  secret: process.env.COOKIE_KEY,
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
// Webhooks and things
app.use('/stripe', require('./stripe'))
// Routes
app.use("/api/chatgpt", require("./routes/gptRoutes"));
app.use("/api/chimp", require("./routes/chimpRoutes"));
app.use("/api/random", require("./routes/randomRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/users", require("./routes/stripeRoutes"));
app.use("/api", require("./routes/checkcharacterRoutes"));
app.use("/api", require("./routes/oauthRoutes"));


app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server is listening on ${PORT}`);
});